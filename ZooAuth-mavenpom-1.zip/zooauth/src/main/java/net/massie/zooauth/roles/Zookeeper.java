package net.massie.zooauth.roles;

public class Zookeeper extends AbstractRole {

	@Override
	public String getDataFilename() {
		return "zookeeper.txt";
	}
}
