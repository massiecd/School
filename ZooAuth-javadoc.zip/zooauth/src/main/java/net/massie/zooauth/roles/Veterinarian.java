package net.massie.zooauth.roles;

public final class Veterinarian extends AbstractRole {

	@Override
	public String getDataFilename() {
		return "veterinarian.txt";
	}
}
