package net.massie.zooauth.roles;

public final class Zookeeper extends AbstractRole {

	@Override
	public String getDataFilename() {
		return "zookeeper.txt";
	}
}
