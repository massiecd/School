package net.massie.zooauth.roles;

public interface IRole {
	public void setFilePath(final String path);
	public String getData();
}
